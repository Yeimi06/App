import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  FlatList
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Chrome as Home, Bell, TriangleAlert as AlertTriangle, Calendar, Check, Clock, Trash2, FileText, Eye } from 'lucide-react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Card } from '@/components/ui/Card';
import { useFocusEffect } from '@react-navigation/native';

interface Notification {
  id: string;
  type: 'reminder' | 'incident' | 'visit';
  title: string;
  message: string;
  date: string;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high';
  data?: any;
}

export default function NotificationsScreen() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [activeTab, setActiveTab] = useState<'reminders' | 'incidents'>('reminders');

  // Use useFocusEffect to reload notifications when screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      loadNotifications();
    }, [])
  );

  const loadNotifications = async () => {
    try {
      const [scheduledVisits, incidents, storedNotifications] = await Promise.all([
        AsyncStorage.getItem('scheduledVisits'),
        AsyncStorage.getItem('incidents'),
        AsyncStorage.getItem('notifications')
      ]);

      const visits = scheduledVisits ? JSON.parse(scheduledVisits) : [];
      const incidentsList = incidents ? JSON.parse(incidents) : [];
      const existingNotifications = storedNotifications ? JSON.parse(storedNotifications) : [];

      const generatedNotifications: Notification[] = [...existingNotifications];

      // Generate visit reminders for unresolved visits
      visits.forEach((visit: any) => {
        if (!visit.isResolved) {
          const existingNotification = generatedNotifications.find(n => n.id === `visit-${visit.id}`);
          if (!existingNotification) {
            const visitDate = new Date(visit.visitDate);
            const today = new Date();
            const diffTime = visitDate.getTime() - today.getTime();
            const diffDays = Math.ceil(diffTime / (1000 * 3600 * 24));

            // Show reminders for visits within the next 30 days or overdue visits
            if (diffDays <= 30) {
              let priority: 'low' | 'medium' | 'high' = 'medium';
              if (diffDays < 0) priority = 'high'; // Overdue
              else if (diffDays <= 3) priority = 'high'; // Within 3 days
              else if (diffDays <= 7) priority = 'medium'; // Within a week

              generatedNotifications.push({
                id: `visit-${visit.id}`,
                type: 'visit',
                title: diffDays < 0 ? 'Visita Vencida' : 'Recordatorio de Visita',
                message: `Visita ${diffDays < 0 ? 'vencida' : 'programada'} a ${visit.institution} para el ${visit.visitDate}${visit.visitTime ? ` a las ${visit.visitTime}` : ''}`,
                date: visit.createdAt || new Date().toISOString(),
                isRead: false,
                priority,
                data: visit
              });
            }
          }
        }
      });

      // Generate incident alerts for unresolved incidents
      incidentsList.forEach((incident: any) => {
        if (!incident.isResolved) {
          const existingNotification = generatedNotifications.find(n => n.id === `incident-${incident.id}`);
          if (!existingNotification) {
            generatedNotifications.push({
              id: `incident-${incident.id}`,
              type: 'incident',
              title: 'Incidencia Pendiente',
              message: `${incident.incidentType || 'Incidencia'} en ${incident.institution} - Prioridad: ${incident.priority || 'Media'}`,
              date: incident.createdAt,
              isRead: false,
              priority: incident.priority === 'Alta' ? 'high' : incident.priority === 'Media' ? 'medium' : 'low',
              data: incident
            });
          }
        }
      });

      // Sort notifications by priority and date
      generatedNotifications.sort((a, b) => {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      });

      setNotifications(generatedNotifications);

      // Save updated notifications
      await AsyncStorage.setItem('notifications', JSON.stringify(generatedNotifications));
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  };

  const handleMarkAsRead = async (id: string) => {
    const updatedNotifications = notifications.map(notification =>
      notification.id === id
        ? { ...notification, isRead: true }
        : notification
    );
    setNotifications(updatedNotifications);
    
    try {
      await AsyncStorage.setItem('notifications', JSON.stringify(updatedNotifications));
    } catch (error) {
      console.error('Error saving notifications:', error);
    }
  };

  const handlePostpone = (id: string) => {
    Alert.alert(
      'Posponer Notificación',
      '¿Cuándo quieres que te recordemos?',
      [
        { text: 'En 1 hora', onPress: () => postponeNotification(id, 1) },
        { text: 'En 1 día', onPress: () => postponeNotification(id, 24) },
        { text: 'En 1 semana', onPress: () => postponeNotification(id, 168) },
        { text: 'Cancelar', style: 'cancel' }
      ]
    );
  };

  const postponeNotification = async (id: string, hours: number) => {
    const newDate = new Date(Date.now() + hours * 60 * 60 * 1000);
    const updatedNotifications = notifications.map(notification =>
      notification.id === id
        ? { ...notification, date: newDate.toISOString(), isRead: false }
        : notification
    );
    setNotifications(updatedNotifications);
    
    try {
      await AsyncStorage.setItem('notifications', JSON.stringify(updatedNotifications));
    } catch (error) {
      console.error('Error saving notifications:', error);
    }
    
    Alert.alert('Éxito', `Notificación pospuesta por ${hours} ${hours === 1 ? 'hora' : hours < 24 ? 'horas' : hours === 24 ? 'día' : 'días'}`);
  };

  const handleDelete = async (id: string) => {
    Alert.alert(
      'Eliminar Notificación',
      '¿Estás seguro que deseas eliminar esta notificación?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Eliminar',
          style: 'destructive',
          onPress: async () => {
            const updatedNotifications = notifications.filter(n => n.id !== id);
            setNotifications(updatedNotifications);
            
            try {
              await AsyncStorage.setItem('notifications', JSON.stringify(updatedNotifications));
            } catch (error) {
              console.error('Error saving notifications:', error);
            }
          }
        }
      ]
    );
  };

  const handleViewDetails = (notification: Notification) => {
    if (notification.data) {
      let details = '';
      if (notification.type === 'visit') {
        const visit = notification.data;
        details = `
VISITA PROGRAMADA

Institución: ${visit.institution}
Fecha: ${visit.visitDate}
Hora: ${visit.visitTime || 'No especificada'}
Técnico: ${visit.assignedTechnician || 'No asignado'}
Objetivo: ${visit.objective || 'No especificado'}
Estado: ${visit.isResolved ? 'Realizada' : 'Pendiente'}
Contacto: ${visit.institutionContact || 'No especificado'}
        `;
      } else if (notification.type === 'incident') {
        const incident = notification.data;
        details = `
INCIDENCIA

Institución: ${incident.institution}
Tipo: ${incident.incidentType}
Prioridad: ${incident.priority}
Estado: ${incident.status}
Descripción: ${incident.description}
Técnico: ${incident.assignedTechnician || 'No asignado'}
Fecha del reporte: ${incident.reportDate}
        `;
      }
      Alert.alert('Detalles', details.trim());
    }
  };

  const handleResolveFromNotification = async (notification: Notification) => {
    if (!notification.data) return;

    const actionText = notification.type === 'visit' ? 'realizada' : 'resuelta';
    const statusText = notification.type === 'visit' ? 'Realizada' : 'Resuelta';
    
    Alert.alert(
      `Marcar como ${statusText}`,
      `¿Estás seguro que deseas marcar esta ${notification.type === 'visit' ? 'visita' : 'incidencia'} como ${actionText}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Confirmar', 
          onPress: async () => {
            try {
              let storageKey = '';
              if (notification.type === 'incident') storageKey = 'incidents';
              else if (notification.type === 'visit') storageKey = 'scheduledVisits';

              if (!storageKey) return;

              const existingData = await AsyncStorage.getItem(storageKey);
              const dataArray = existingData ? JSON.parse(existingData) : [];
              
              const updatedArray = dataArray.map((item: any) => 
                item.id === notification.data.id ? { ...item, isResolved: true } : item
              );

              await AsyncStorage.setItem(storageKey, JSON.stringify(updatedArray));

              // Remove the notification
              await handleDelete(notification.id);

              // Reload notifications
              loadNotifications();
              
              Alert.alert('Éxito', `Marcado como ${actionText} correctamente`);
            } catch (error) {
              Alert.alert('Error', `No se pudo marcar como ${actionText}`);
            }
          }
        }
      ]
    );
  };

  const filteredNotifications = notifications.filter(notification => {
    if (activeTab === 'reminders') {
      return notification.type === 'reminder' || notification.type === 'visit';
    } else {
      return notification.type === 'incident';
    }
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return '#DC2626';
      case 'medium': return '#D97706';
      case 'low': return '#059669';
      default: return '#6B7280';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'reminder': return Calendar;
      case 'incident': return AlertTriangle;
      case 'visit': return Calendar;
      default: return Bell;
    }
  };

  const renderNotificationItem = ({ item }: { item: Notification }) => {
    const IconComponent = getTypeIcon(item.type);
    
    return (
      <Card style={[
        styles.notificationCard,
        !item.isRead && styles.unreadNotification
      ]}>
        <View style={styles.notificationHeader}>
          <View style={[
            styles.notificationIcon,
            { backgroundColor: `${getPriorityColor(item.priority)}15` }
          ]}>
            <IconComponent 
              color={getPriorityColor(item.priority)} 
              size={20} 
            />
          </View>
          <View style={styles.notificationContent}>
            <Text style={[
              styles.notificationTitle,
              !item.isRead && styles.unreadTitle
            ]}>
              {item.title}
            </Text>
            <Text style={styles.notificationMessage}>{item.message}</Text>
            <Text style={styles.notificationDate}>
              {new Date(item.date).toLocaleDateString('es-ES', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </Text>
          </View>
          <View style={[
            styles.priorityIndicator,
            { backgroundColor: getPriorityColor(item.priority) }
          ]} />
        </View>

        <View style={styles.notificationActions}>
          {item.data && (
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => handleViewDetails(item)}
            >
              <Eye color="#4F46E5" size={16} />
              <Text style={styles.actionText}>Ver detalles</Text>
            </TouchableOpacity>
          )}
          
          {item.data && (
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => handleResolveFromNotification(item)}
            >
              <Check color="#059669" size={16} />
              <Text style={styles.actionText}>
                Marcar como {item.type === 'visit' ? 'realizada' : 'resuelta'}
              </Text>
            </TouchableOpacity>
          )}
          
          {!item.isRead && (
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => handleMarkAsRead(item.id)}
            >
              <Check color="#059669" size={16} />
              <Text style={styles.actionText}>Marcar leído</Text>
            </TouchableOpacity>
          )}
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => handlePostpone(item.id)}
          >
            <Clock color="#D97706" size={16} />
            <Text style={styles.actionText}>Posponer</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => handleDelete(item.id)}
          >
            <Trash2 color="#DC2626" size={16} />
            <Text style={styles.actionText}>Eliminar</Text>
          </TouchableOpacity>
        </View>
      </Card>
    );
  };

  return (
    <LinearGradient
      colors={['#f8fafc', '#e2e8f0']}
      style={styles.container}
    >
      <LinearGradient
        colors={['#4F46E5', '#4338CA']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={() => router.push('/(tabs)')}
          >
            <Home color="#FFFFFF" size={24} />
          </TouchableOpacity>
          <Text style={styles.title}>Notificaciones</Text>
          <View style={styles.placeholder} />
        </View>
      </LinearGradient>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'reminders' && styles.activeTab
          ]}
          onPress={() => setActiveTab('reminders')}
        >
          <Calendar color={activeTab === 'reminders' ? '#4F46E5' : '#666'} size={20} />
          <Text style={[
            styles.tabText,
            activeTab === 'reminders' && styles.activeTabText
          ]}>
            Recordatorios ({filteredNotifications.length})
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'incidents' && styles.activeTab
          ]}
          onPress={() => setActiveTab('incidents')}
        >
          <AlertTriangle color={activeTab === 'incidents' ? '#4F46E5' : '#666'} size={20} />
          <Text style={[
            styles.tabText,
            activeTab === 'incidents' && styles.activeTabText
          ]}>
            Incidencias ({notifications.filter(n => n.type === 'incident').length})
          </Text>
        </TouchableOpacity>
      </View>

      {filteredNotifications.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Bell color="#CCC" size={64} />
          <Text style={styles.emptyTitle}>No hay notificaciones</Text>
          <Text style={styles.emptyText}>
            No tienes {activeTab === 'reminders' ? 'recordatorios de visitas' : 'alertas de incidencias'} pendientes
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredNotifications}
          renderItem={renderNotificationItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  homeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 40,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E9ECEF',
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    marginHorizontal: 4,
  },
  activeTab: {
    backgroundColor: '#EEF2FF',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginLeft: 8,
  },
  activeTabText: {
    color: '#4F46E5',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#999',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
  },
  listContainer: {
    padding: 20,
    paddingBottom: 100,
  },
  notificationCard: {
    marginBottom: 16,
  },
  unreadNotification: {
    borderLeftWidth: 4,
    borderLeftColor: '#4F46E5',
  },
  notificationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  notificationIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  unreadTitle: {
    fontWeight: 'bold',
  },
  notificationMessage: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
    lineHeight: 20,
  },
  notificationDate: {
    fontSize: 12,
    color: '#999',
  },
  priorityIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginLeft: 8,
    marginTop: 4,
  },
  notificationActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F8F9FA',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginBottom: 4,
  },
  actionText: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
});