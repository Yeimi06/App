import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { User, Mail, Calendar, LogOut, Settings, CreditCard as Edit } from 'lucide-react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ProfileScreen() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const currentUser = await AsyncStorage.getItem('currentUser');
      if (currentUser) {
        setUser(JSON.parse(currentUser));
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Cerrar Sesión',
      '¿Estás seguro que deseas cerrar sesión?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Sí, cerrar sesión', 
          onPress: async () => {
            try {
              await AsyncStorage.removeItem('currentUser');
              router.replace('/');
            } catch (error) {
              console.error('Error logging out:', error);
              router.replace('/');
            }
          }
        }
      ]
    );
  };

  const profileOptions = [
    {
      title: 'Editar Perfil',
      icon: Edit,
      onPress: () => Alert.alert('Próximamente', 'Esta función estará disponible pronto')
    },
    {
      title: 'Configuración',
      icon: Settings,
      onPress: () => Alert.alert('Próximamente', 'Esta función estará disponible pronto')
    },
    {
      title: 'Cerrar Sesión',
      icon: LogOut,
      onPress: handleLogout,
      isDestructive: true
    }
  ];

  return (
    <LinearGradient
      colors={['#475569', '#64748B', '#94A3B8']}
      style={styles.container}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Mi Perfil</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Profile Card */}
        <View style={styles.profileCard}>
          <View style={styles.avatarContainer}>
            <User color="#475569" size={60} />
          </View>
          
          <Text style={styles.userName}>{user?.fullName || 'Usuario'}</Text>
          <Text style={styles.userEmail}>{user?.email || 'correo@ejemplo.com'}</Text>
          
          <View style={styles.userInfo}>
            <View style={styles.infoItem}>
              <Mail color="#475569" size={20} />
              <Text style={styles.infoText}>{user?.email || 'No disponible'}</Text>
            </View>
            
            <View style={styles.infoItem}>
              <Calendar color="#475569" size={20} />
              <Text style={styles.infoText}>
                Miembro desde {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
              </Text>
            </View>
          </View>
        </View>

        {/* Options */}
        <View style={styles.optionsContainer}>
          {profileOptions.map((option, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.optionItem,
                option.isDestructive && styles.destructiveOption
              ]}
              onPress={option.onPress}
            >
              <option.icon 
                color={option.isDestructive ? '#DC2626' : '#475569'} 
                size={24} 
              />
              <Text style={[
                styles.optionText,
                option.isDestructive && styles.destructiveText
              ]}>
                {option.title}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  scrollContainer: {
    paddingHorizontal: 24,
    paddingBottom: 120,
  },
  profileCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 32,
    alignItems: 'center',
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8,
  },
  avatarContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F1F5F9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 3,
    borderColor: '#475569',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  userEmail: {
    fontSize: 16,
    color: '#666',
    marginBottom: 24,
  },
  userInfo: {
    width: '100%',
    gap: 16,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 12,
    flex: 1,
  },
  optionsContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    padding: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 4,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 16,
    marginVertical: 4,
  },
  destructiveOption: {
    backgroundColor: '#FEF2F2',
  },
  optionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginLeft: 16,
    flex: 1,
  },
  destructiveText: {
    color: '#DC2626',
  },
});