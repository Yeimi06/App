import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Linking,
  Platform
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Chrome as Home, Search, MapPin, Navigation, Phone, Mail, Building } from 'lucide-react-native';
import { router } from 'expo-router';

interface SearchResult {
  id: string;
  name: string;
  address: string;
  phone?: string;
  email?: string;
  coordinates: { lat: number; lng: number };
  type: string;
}

export default function LocationScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSchool, setSelectedSchool] = useState<SearchResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      Alert.alert('Error', 'Por favor ingresa el nombre de una institución');
      return;
    }

    setIsSearching(true);
    setSearchResults([]);
    setSelectedSchool(null);
    
    setTimeout(() => {
      const mockResults: SearchResult[] = [];
      const query = searchQuery.toLowerCase();
      
      if (query.includes('josé') || query.includes('marti')) {
        mockResults.push({
          id: '1',
          name: 'Escuela Primaria José Martí',
          address: 'Calle Principal, Penonomé, Coclé',
          phone: '+507 997-1234',
          email: 'josemarti@meduca.gob.pa',
          coordinates: { lat: 8.5197, lng: -80.3582 },
          type: 'Primaria'
        });
      }
      
      if (query.includes('belisario') || query.includes('porras')) {
        mockResults.push({
          id: '2',
          name: 'Colegio Secundario Belisario Porras',
          address: 'Avenida Central, Aguadulce, Coclé',
          phone: '+507 997-5678',
          email: 'belisario@meduca.gob.pa',
          coordinates: { lat: 8.2447, lng: -80.5447 },
          type: 'Secundaria'
        });
      }
      
      if (query.includes('pintada')) {
        mockResults.push({
          id: '3',
          name: 'Centro Educativo La Pintada',
          address: 'Barrio Centro, La Pintada, Coclé',
          phone: '+507 997-9012',
          email: 'lapintada@meduca.gob.pa',
          coordinates: { lat: 8.6086, lng: -80.4208 },
          type: 'Básica General'
        });
      }
      
      if (query.includes('penonomé') || query.includes('instituto')) {
        mockResults.push({
          id: '4',
          name: 'Instituto Nacional de Penonomé',
          address: 'Vía Interamericana, Penonomé, Coclé',
          phone: '+507 997-7890',
          email: 'inpenome@meduca.gob.pa',
          coordinates: { lat: 8.5150, lng: -80.3500 },
          type: 'Secundaria'
        });
      }

      if (query.includes('escuela') || query.includes('colegio') || query.includes('centro')) {
        if (mockResults.length === 0) {
          mockResults.push({
            id: '5',
            name: `Centro Educativo ${searchQuery}`,
            address: 'Ubicación en Coclé, Panamá',
            coordinates: { lat: 8.4000, lng: -80.3000 },
            type: 'Institución Educativa'
          });
        }
      }

      setSearchResults(mockResults);
      setIsSearching(false);

      if (mockResults.length === 0) {
        Alert.alert('No encontrado', 'No se encontraron instituciones con ese nombre. Intenta con otro término de búsqueda.');
      }
    }, 1000);
  };

  const handleSelectSchool = (school: SearchResult) => {
    setSelectedSchool(school);
    setSearchQuery(school.name);
    setSearchResults([]);
    Alert.alert('Institución Seleccionada', `Has seleccionado: ${school.name}`);
  };

  const handleGetDirections = () => {
    if (selectedSchool) {
      const { lat, lng } = selectedSchool.coordinates;
      const label = encodeURIComponent(selectedSchool.name);
      
      let url = '';
      
      if (Platform.OS === 'ios') {
        url = `http://maps.apple.com/?q=${label}&ll=${lat},${lng}`;
      } else if (Platform.OS === 'android') {
        url = `geo:${lat},${lng}?q=${lat},${lng}(${label})`;
      } else {
        // Web fallback
        url = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}&query_place_id=${label}`;
      }

      Linking.canOpenURL(url)
        .then((supported) => {
          if (supported) {
            return Linking.openURL(url);
          } else {
            // Fallback to Google Maps web
            const webUrl = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
            return Linking.openURL(webUrl);
          }
        })
        .catch((err) => {
          console.error('Error opening maps:', err);
          Alert.alert(
            'Error',
            'No se pudo abrir la aplicación de mapas. Coordenadas: ' + lat + ', ' + lng
          );
        });
    }
  };

  return (
    <LinearGradient
      colors={['#f8fafc', '#e2e8f0']}
      style={styles.container}
    >
      <LinearGradient
        colors={['#6F42C1', '#5A32A3']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={() => router.push('/(tabs)')}
          >
            <Home color="#FFFFFF" size={24} />
          </TouchableOpacity>
          <Text style={styles.title}>Ubicación</Text>
          <View style={styles.placeholder} />
        </View>
      </LinearGradient>

      <ScrollView 
        style={styles.scrollContainer} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.searchSection}>
          <Text style={styles.sectionTitle}>Buscar Institución Educativa</Text>
          
          <View style={styles.searchContainer}>
            <View style={styles.searchInputContainer}>
              <Search color="#666" size={20} style={styles.searchIcon} />
              <TextInput
                style={styles.searchInput}
                placeholder="Ingresa el nombre del colegio o institución"
                placeholderTextColor="#9CA3AF"
                value={searchQuery}
                onChangeText={setSearchQuery}
                onSubmitEditing={handleSearch}
              />
            </View>
            
            <TouchableOpacity
              style={[styles.searchButton, isSearching && styles.searchButtonDisabled]}
              onPress={handleSearch}
              disabled={isSearching}
            >
              <Text style={styles.searchButtonText}>
                {isSearching ? 'Buscando...' : 'Buscar'}
              </Text>
            </TouchableOpacity>
          </View>

          {searchResults.length > 0 && (
            <View style={styles.resultsContainer}>
              <Text style={styles.resultsTitle}>Resultados de búsqueda:</Text>
              {searchResults.map(result => (
                <TouchableOpacity
                  key={result.id}
                  style={styles.resultItem}
                  onPress={() => handleSelectSchool(result)}
                >
                  <Building color="#6F42C1" size={20} />
                  <View style={styles.resultInfo}>
                    <Text style={styles.resultName}>{result.name}</Text>
                    <Text style={styles.resultAddress}>{result.address}</Text>
                    <Text style={styles.resultType}>{result.type}</Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        {selectedSchool && (
          <View style={styles.resultSection}>
            <Text style={styles.sectionTitle}>Ubicación Encontrada</Text>
            
            <View style={styles.mapPlaceholder}>
              <MapPin color="#6F42C1" size={48} />
              <Text style={styles.mapText}>Mapa GPS</Text>
              <Text style={styles.mapSubtext}>
                {selectedSchool.name}
              </Text>
              <Text style={styles.coordinatesText}>
                Lat: {selectedSchool.coordinates.lat}, Lng: {selectedSchool.coordinates.lng}
              </Text>
            </View>

            <View style={styles.schoolDetails}>
              <View style={styles.schoolHeader}>
                <Building color="#6F42C1" size={24} />
                <View style={styles.schoolInfo}>
                  <Text style={styles.schoolName}>{selectedSchool.name}</Text>
                  <Text style={styles.schoolType}>{selectedSchool.type}</Text>
                </View>
              </View>

              <View style={styles.detailItem}>
                <MapPin color="#666" size={20} />
                <Text style={styles.detailText}>{selectedSchool.address}</Text>
              </View>

              {selectedSchool.phone && (
                <View style={styles.detailItem}>
                  <Phone color="#666" size={20} />
                  <Text style={styles.detailText}>{selectedSchool.phone}</Text>
                </View>
              )}

              {selectedSchool.email && (
                <View style={styles.detailItem}>
                  <Mail color="#666" size={20} />
                  <Text style={styles.detailText}>{selectedSchool.email}</Text>
                </View>
              )}

              <TouchableOpacity
                style={styles.directionsButton}
                onPress={handleGetDirections}
              >
                <Navigation color="#FFFFFF" size={20} style={styles.buttonIcon} />
                <Text style={styles.directionsButtonText}>Obtener Direcciones GPS</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  homeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 40,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 100,
  },
  searchSection: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  searchContainer: {
    gap: 12,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#E9ECEF',
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    paddingVertical: 16,
  },
  searchButton: {
    backgroundColor: '#6F42C1',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    shadowColor: '#6F42C1',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  searchButtonDisabled: {
    backgroundColor: '#B19CD9',
  },
  searchButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultsContainer: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E9ECEF',
  },
  resultsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  resultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#F8F9FA',
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E9ECEF',
  },
  resultInfo: {
    marginLeft: 12,
    flex: 1,
  },
  resultName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  resultAddress: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  resultType: {
    fontSize: 12,
    color: '#6F42C1',
    marginTop: 2,
    fontWeight: '500',
  },
  resultSection: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  mapPlaceholder: {
    height: 200,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#6F42C1',
    borderStyle: 'dashed',
  },
  mapText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#6F42C1',
    marginTop: 8,
  },
  mapSubtext: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
    textAlign: 'center',
    fontWeight: '600',
  },
  coordinatesText: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  schoolDetails: {
    gap: 16,
  },
  schoolHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  schoolInfo: {
    marginLeft: 12,
    flex: 1,
  },
  schoolName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  schoolType: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  detailText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 12,
    flex: 1,
  },
  directionsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#28A745',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
    marginTop: 8,
    shadowColor: '#28A745',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  buttonIcon: {
    marginRight: 8,
  },
  directionsButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});