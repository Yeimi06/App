import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Image,
  Platform
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Chrome as Home, Building, Calendar, Clock, Target, User, Phone, MessageSquare, Camera, Save, X } from 'lucide-react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';

export default function TechnicalReportScreen() {
  const [formData, setFormData] = useState({
    institution: '',
    visitDate: '',
    arrivalTime: '',
    departureTime: '',
    objective: '',
    technicianName: '',
    technicianPhone: '',
    schoolContact: '',
    contactPhone: '',
    observations: ''
  });

  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.institution.trim()) {
      newErrors.institution = 'La institución es requerida';
    }
    if (!formData.visitDate.trim()) {
      newErrors.visitDate = 'La fecha de visita es requerida';
    }
    if (!formData.technicianName.trim()) {
      newErrors.technicianName = 'El nombre del técnico es requerido';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const requestPermissions = async () => {
    if (Platform.OS !== 'web') {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permisos requeridos', 'Se necesitan permisos para acceder a la galería');
        return false;
      }
      
      const cameraStatus = await ImagePicker.requestCameraPermissionsAsync();
      if (cameraStatus.status !== 'granted') {
        Alert.alert('Permisos requeridos', 'Se necesitan permisos para usar la cámara');
        return false;
      }
    }
    return true;
  };

  const handleImageSelection = async () => {
    const hasPermissions = await requestPermissions();
    if (!hasPermissions) return;

    Alert.alert(
      'Seleccionar Imagen',
      'Elige una opción',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Galería', onPress: () => pickImageFromGallery() },
        { text: 'Cámara', onPress: () => takePhoto() }
      ]
    );
  };

  const pickImageFromGallery = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setSelectedImages(prev => [...prev, result.assets[0].uri]);
      }
    } catch (error) {
      Alert.alert('Error', 'No se pudo seleccionar la imagen');
    }
  };

  const takePhoto = async () => {
    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setSelectedImages(prev => [...prev, result.assets[0].uri]);
      }
    } catch (error) {
      Alert.alert('Error', 'No se pudo tomar la foto');
    }
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSaveReport = async () => {
    if (!validateForm()) {
      Alert.alert('Error', 'Por favor completa los campos obligatorios');
      return;
    }

    setIsLoading(true);

    try {
      const existingReports = await AsyncStorage.getItem('technicalReports');
      const reports = existingReports ? JSON.parse(existingReports) : [];

      const newReport = {
        id: Date.now().toString(),
        ...formData,
        images: selectedImages,
        isResolved: true, // Technical reports are always completed
        createdAt: new Date().toISOString()
      };

      reports.push(newReport);
      await AsyncStorage.setItem('technicalReports', JSON.stringify(reports));

      Alert.alert('Éxito', 'Informe técnico guardado correctamente', [
        { text: 'OK', onPress: () => {
          setFormData({
            institution: '',
            visitDate: '',
            arrivalTime: '',
            departureTime: '',
            objective: '',
            technicianName: '',
            technicianPhone: '',
            schoolContact: '',
            contactPhone: '',
            observations: ''
          });
          setSelectedImages([]);
          setErrors({});
        }}
      ]);
    } catch (error) {
      Alert.alert('Error', 'No se pudo guardar el informe');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <LinearGradient
      colors={['#f8fafc', '#e2e8f0']}
      style={styles.container}
    >
      <LinearGradient
        colors={['#4A90E2', '#357ABD']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={() => router.push('/(tabs)')}
          >
            <Home color="#FFFFFF" size={24} />
          </TouchableOpacity>
          <Text style={styles.title}>Informe Técnico</Text>
          <View style={styles.placeholder} />
        </View>
      </LinearGradient>

      <ScrollView 
        style={styles.scrollContainer} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Información de la Institución</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Institución Educativa *</Text>
            <View style={[styles.inputContainer, errors.institution && styles.errorBorder]}>
              <Building color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Nombre de la institución"
                placeholderTextColor="#9CA3AF"
                value={formData.institution}
                onChangeText={(value) => handleInputChange('institution', value)}
              />
            </View>
            {errors.institution && <Text style={styles.errorText}>{errors.institution}</Text>}
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Detalles de la Visita</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Fecha de Visita *</Text>
            <View style={[styles.inputContainer, errors.visitDate && styles.errorBorder]}>
              <Calendar color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="DD/MM/YYYY"
                placeholderTextColor="#9CA3AF"
                value={formData.visitDate}
                onChangeText={(value) => handleInputChange('visitDate', value)}
              />
            </View>
            {errors.visitDate && <Text style={styles.errorText}>{errors.visitDate}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Hora de Llegada</Text>
            <View style={styles.inputContainer}>
              <Clock color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="HH:MM"
                placeholderTextColor="#9CA3AF"
                value={formData.arrivalTime}
                onChangeText={(value) => handleInputChange('arrivalTime', value)}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Hora de Salida</Text>
            <View style={styles.inputContainer}>
              <Clock color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="HH:MM"
                placeholderTextColor="#9CA3AF"
                value={formData.departureTime}
                onChangeText={(value) => handleInputChange('departureTime', value)}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Objetivo de la Visita</Text>
            <View style={styles.inputContainer}>
              <Target color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={[styles.textInput, styles.textArea]}
                placeholder="Describe el objetivo de la visita"
                placeholderTextColor="#9CA3AF"
                value={formData.objective}
                onChangeText={(value) => handleInputChange('objective', value)}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Información del Técnico</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Nombre del Técnico *</Text>
            <View style={[styles.inputContainer, errors.technicianName && styles.errorBorder]}>
              <User color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Nombre completo del técnico"
                placeholderTextColor="#9CA3AF"
                value={formData.technicianName}
                onChangeText={(value) => handleInputChange('technicianName', value)}
              />
            </View>
            {errors.technicianName && <Text style={styles.errorText}>{errors.technicianName}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Celular del Técnico</Text>
            <View style={styles.inputContainer}>
              <Phone color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Número de teléfono del técnico"
                placeholderTextColor="#9CA3AF"
                value={formData.technicianPhone}
                onChangeText={(value) => handleInputChange('technicianPhone', value)}
                keyboardType="phone-pad"
              />
            </View>
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Información del Encargado</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Encargado de la Escuela</Text>
            <View style={styles.inputContainer}>
              <User color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Nombre del encargado de la institución"
                placeholderTextColor="#9CA3AF"
                value={formData.schoolContact}
                onChangeText={(value) => handleInputChange('schoolContact', value)}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Celular del Encargado</Text>
            <View style={styles.inputContainer}>
              <Phone color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Número de teléfono del encargado"
                placeholderTextColor="#9CA3AF"
                value={formData.contactPhone}
                onChangeText={(value) => handleInputChange('contactPhone', value)}
                keyboardType="phone-pad"
              />
            </View>
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Información Adicional</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Observaciones</Text>
            <View style={styles.inputContainer}>
              <MessageSquare color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={[styles.textInput, styles.textArea]}
                placeholder="Observaciones adicionales sobre la visita"
                placeholderTextColor="#9CA3AF"
                value={formData.observations}
                onChangeText={(value) => handleInputChange('observations', value)}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
            </View>
          </View>

          <View style={styles.photoSection}>
            <Text style={styles.label}>Evidencia Fotográfica</Text>
            <TouchableOpacity
              style={styles.photoButton}
              onPress={handleImageSelection}
            >
              <Camera color="#4A90E2" size={20} />
              <Text style={styles.photoButtonText}>Agregar Foto</Text>
            </TouchableOpacity>

            {selectedImages.length > 0 && (
              <View style={styles.imageGrid}>
                {selectedImages.map((uri, index) => (
                  <View key={index} style={styles.imageContainer}>
                    <Image source={{ uri }} style={styles.selectedImage} />
                    <TouchableOpacity
                      style={styles.removeImageButton}
                      onPress={() => removeImage(index)}
                    >
                      <X color="#FFFFFF" size={16} />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>

        <View style={styles.actionCard}>
          <TouchableOpacity
            style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}
            onPress={handleSaveReport}
            disabled={isLoading}
          >
            <Save color="#FFFFFF" size={20} style={styles.buttonIcon} />
            <Text style={styles.saveButtonText}>
              {isLoading ? 'Guardando...' : 'Guardar Informe'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  homeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 40,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 100,
  },
  sectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minHeight: 52,
  },
  errorBorder: {
    borderColor: '#EF4444',
  },
  inputIcon: {
    marginRight: 12,
    marginTop: 2,
  },
  textInput: {
    flex: 1,
    fontSize: 16,
    color: '#374151',
    paddingVertical: 4,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  errorText: {
    fontSize: 14,
    color: '#EF4444',
    marginTop: 4,
  },
  photoSection: {
    marginTop: 8,
  },
  photoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderWidth: 2,
    borderColor: '#4A90E2',
    borderStyle: 'dashed',
    marginBottom: 16,
  },
  photoButtonText: {
    color: '#4A90E2',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  imageGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  imageContainer: {
    position: 'relative',
    width: 100,
    height: 100,
  },
  selectedImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    backgroundColor: '#F3F4F6',
  },
  removeImageButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#EF4444',
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#28A745',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
    shadowColor: '#28A745',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  saveButtonDisabled: {
    backgroundColor: '#A0D6A0',
  },
  buttonIcon: {
    marginRight: 8,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});