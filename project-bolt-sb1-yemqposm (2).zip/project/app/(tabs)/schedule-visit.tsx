import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Chrome as Home, Building, Calendar, Clock, Target, User, Phone, Save, Bell } from 'lucide-react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ScheduleVisitScreen() {
  const [formData, setFormData] = useState({
    institution: '',
    visitDate: '',
    visitTime: '',
    objective: '',
    assignedTechnician: '',
    institutionContact: ''
  });

  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.institution.trim()) {
      newErrors.institution = 'La institución es requerida';
    }
    if (!formData.visitDate.trim()) {
      newErrors.visitDate = 'La fecha de visita es requerida';
    }
    if (!formData.assignedTechnician.trim()) {
      newErrors.assignedTechnician = 'El técnico asignado es requerido';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const createNotification = async (visitData: any) => {
    try {
      const existingNotifications = await AsyncStorage.getItem('notifications');
      const notifications = existingNotifications ? JSON.parse(existingNotifications) : [];

      const newNotification = {
        id: `visit-reminder-${Date.now()}`,
        type: 'visit',
        title: 'Recordatorio de Visita Programada',
        message: `Visita programada a ${visitData.institution} para el ${visitData.visitDate}${visitData.visitTime ? ` a las ${visitData.visitTime}` : ''}`,
        date: new Date().toISOString(),
        isRead: false,
        priority: 'medium',
        data: visitData
      };

      notifications.push(newNotification);
      await AsyncStorage.setItem('notifications', JSON.stringify(notifications));
    } catch (error) {
      console.error('Error creating notification:', error);
    }
  };

  const handleSaveVisit = async () => {
    if (!validateForm()) {
      Alert.alert('Error', 'Por favor completa los campos obligatorios');
      return;
    }

    setIsLoading(true);

    try {
      const existingVisits = await AsyncStorage.getItem('scheduledVisits');
      const visits = existingVisits ? JSON.parse(existingVisits) : [];

      const newVisit = {
        id: Date.now().toString(),
        ...formData,
        status: 'Pendiente',
        createdAt: new Date().toISOString(),
        isReminder: true,
        isResolved: false // Explicitly set as not resolved
      };

      visits.push(newVisit);
      await AsyncStorage.setItem('scheduledVisits', JSON.stringify(visits));

      // Create notification
      await createNotification(newVisit);

      Alert.alert('Éxito', 'Visita programada correctamente y recordatorio creado', [
        { text: 'OK', onPress: () => {
          setFormData({
            institution: '',
            visitDate: '',
            visitTime: '',
            objective: '',
            assignedTechnician: '',
            institutionContact: ''
          });
          setErrors({});
        }}
      ]);
    } catch (error) {
      Alert.alert('Error', 'No se pudo programar la visita');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <LinearGradient
      colors={['#f8fafc', '#e2e8f0']}
      style={styles.container}
    >
      <LinearGradient
        colors={['#28A745', '#20963D']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={() => router.push('/(tabs)')}
          >
            <Home color="#FFFFFF" size={24} />
          </TouchableOpacity>
          <View style={styles.titleContainer}>
            <Bell color="#FFFFFF" size={24} style={styles.reminderIcon} />
            <Text style={styles.title}>Programar Visita</Text>
          </View>
          <View style={styles.placeholder} />
        </View>
      </LinearGradient>

      <ScrollView 
        style={styles.scrollContainer} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.reminderCard}>
          <View style={styles.reminderHeader}>
            <Bell color="#28A745" size={32} />
            <Text style={styles.reminderTitle}>Crear Recordatorio</Text>
            <Text style={styles.reminderSubtitle}>
              Al programar esta visita se creará automáticamente un recordatorio
            </Text>
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Información de la Visita</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Institución Educativa *</Text>
            <View style={[styles.inputContainer, errors.institution && styles.errorBorder]}>
              <Building color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Nombre de la institución"
                placeholderTextColor="#9CA3AF"
                value={formData.institution}
                onChangeText={(value) => handleInputChange('institution', value)}
              />
            </View>
            {errors.institution && <Text style={styles.errorText}>{errors.institution}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Fecha de la Visita *</Text>
            <View style={[styles.inputContainer, errors.visitDate && styles.errorBorder]}>
              <Calendar color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="DD/MM/YYYY"
                placeholderTextColor="#9CA3AF"
                value={formData.visitDate}
                onChangeText={(value) => handleInputChange('visitDate', value)}
              />
            </View>
            {errors.visitDate && <Text style={styles.errorText}>{errors.visitDate}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Hora de la Visita</Text>
            <View style={styles.inputContainer}>
              <Clock color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="HH:MM"
                placeholderTextColor="#9CA3AF"
                value={formData.visitTime}
                onChangeText={(value) => handleInputChange('visitTime', value)}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Objetivo de la Visita</Text>
            <View style={styles.inputContainer}>
              <Target color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={[styles.textInput, styles.textArea]}
                placeholder="Describe el objetivo de la visita"
                placeholderTextColor="#9CA3AF"
                value={formData.objective}
                onChangeText={(value) => handleInputChange('objective', value)}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Técnico Asignado *</Text>
            <View style={[styles.inputContainer, errors.assignedTechnician && styles.errorBorder]}>
              <User color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Nombre del técnico responsable"
                placeholderTextColor="#9CA3AF"
                value={formData.assignedTechnician}
                onChangeText={(value) => handleInputChange('assignedTechnician', value)}
              />
            </View>
            {errors.assignedTechnician && <Text style={styles.errorText}>{errors.assignedTechnician}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Contacto de la Institución</Text>
            <View style={styles.inputContainer}>
              <Phone color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Número de teléfono de contacto"
                placeholderTextColor="#9CA3AF"
                value={formData.institutionContact}
                onChangeText={(value) => handleInputChange('institutionContact', value)}
                keyboardType="phone-pad"
              />
            </View>
          </View>
        </View>

        <View style={styles.actionCard}>
          <TouchableOpacity
            style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}
            onPress={handleSaveVisit}
            disabled={isLoading}
          >
            <Save color="#FFFFFF" size={20} style={styles.buttonIcon} />
            <Text style={styles.saveButtonText}>
              {isLoading ? 'Guardando...' : 'Guardar Visita'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  homeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  reminderIcon: {
    marginRight: 8,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 40,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 100,
  },
  reminderCard: {
    backgroundColor: '#F0F9FF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    borderLeftWidth: 4,
    borderLeftColor: '#28A745',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  reminderHeader: {
    alignItems: 'center',
  },
  reminderTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginTop: 12,
    marginBottom: 8,
  },
  reminderSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
  },
  sectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minHeight: 52,
  },
  errorBorder: {
    borderColor: '#EF4444',
  },
  inputIcon: {
    marginRight: 12,
    marginTop: 2,
  },
  textInput: {
    flex: 1,
    fontSize: 16,
    color: '#374151',
    paddingVertical: 4,
  },
  textArea: {
    minHeight: 60,
    textAlignVertical: 'top',
  },
  errorText: {
    fontSize: 14,
    color: '#EF4444',
    marginTop: 4,
  },
  actionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#28A745',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
    shadowColor: '#28A745',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  saveButtonDisabled: {
    backgroundColor: '#A0D6A0',
  },
  buttonIcon: {
    marginRight: 8,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});