import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Chrome as Home, Search } from 'lucide-react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';

interface Visit {
  id: string;
  institution: string;
  visitDate: string;
  objective: string;
  technicianName?: string;
  assignedTechnician?: string;
  status?: string;
  createdAt: string;
  type?: string;
  priority?: string;
  incidentType?: string;
  description?: string;
  isResolved?: boolean;
}

export default function HistoryScreen() {
  const [visits, setVisits] = useState<Visit[]>([]);
  const [filteredVisits, setFilteredVisits] = useState<Visit[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  // Use useFocusEffect to reload data when screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      loadVisits();
    }, [])
  );

  useEffect(() => {
    filterVisits();
  }, [visits, searchQuery]);

  const loadVisits = async () => {
    try {
      const [technicalReports, scheduledVisits, incidents] = await Promise.all([
        AsyncStorage.getItem('technicalReports'),
        AsyncStorage.getItem('scheduledVisits'),
        AsyncStorage.getItem('incidents')
      ]);

      const reports = technicalReports ? JSON.parse(technicalReports) : [];
      const scheduled = scheduledVisits ? JSON.parse(scheduledVisits) : [];
      const incidentsList = incidents ? JSON.parse(incidents) : [];

      const allVisits = [
        ...reports.map((report: any) => ({
          ...report,
          type: 'report',
          isResolved: true // Technical reports are always considered completed
        })),
        ...scheduled.map((visit: any) => ({
          ...visit,
          type: 'scheduled',
          isResolved: visit.isResolved || false
        })),
        ...incidentsList.map((incident: any) => ({
          ...incident,
          type: 'incident',
          visitDate: incident.reportDate || incident.createdAt,
          isResolved: incident.isResolved || false
        }))
      ];

      // Sort by creation date (newest first)
      allVisits.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      setVisits(allVisits);
    } catch (error) {
      console.error('Error loading visits:', error);
    }
  };

  const filterVisits = () => {
    let filtered = visits;

    // Filter by search query
    if (searchQuery.trim()) {
      filtered = filtered.filter(visit => 
        visit.institution.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (visit.technicianName && visit.technicianName.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (visit.assignedTechnician && visit.assignedTechnician.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (visit.objective && visit.objective.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (visit.description && visit.description.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    setFilteredVisits(filtered);
  };

  const handleMarkAsResolved = async (visit: Visit) => {
    const actionText = visit.type === 'scheduled' ? 'realizada' : 'resuelta';
    const statusText = visit.type === 'scheduled' ? 'Realizada' : 'Resuelta';
    
    Alert.alert(
      `Marcar como ${statusText}`,
      `¿Estás seguro que deseas marcar esta ${visit.type === 'scheduled' ? 'visita' : 'incidencia'} como ${actionText}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Confirmar', 
          onPress: async () => {
            try {
              let storageKey = '';
              if (visit.type === 'incident') storageKey = 'incidents';
              else if (visit.type === 'scheduled') storageKey = 'scheduledVisits';

              if (!storageKey) return;

              const existingData = await AsyncStorage.getItem(storageKey);
              const dataArray = existingData ? JSON.parse(existingData) : [];
              
              const updatedArray = dataArray.map((item: any) => 
                item.id === visit.id ? { ...item, isResolved: true } : item
              );

              await AsyncStorage.setItem(storageKey, JSON.stringify(updatedArray));

              // Remove from notifications if it's an incident
              if (visit.type === 'incident') {
                const existingNotifications = await AsyncStorage.getItem('notifications');
                const notifications = existingNotifications ? JSON.parse(existingNotifications) : [];
                const filteredNotifications = notifications.filter((n: any) => n.id !== `incident-${visit.id}`);
                await AsyncStorage.setItem('notifications', JSON.stringify(filteredNotifications));
              }

              // Reload data
              loadVisits();
              
              Alert.alert('Éxito', `Marcado como ${actionText} correctamente`);
            } catch (error) {
              Alert.alert('Error', `No se pudo marcar como ${actionText}`);
            }
          }
        }
      ]
    );
  };

  const handleViewDetails = (visit: Visit) => {
    let details = '';
    
    if (visit.type === 'report') {
      details = `
INFORME TÉCNICO

Institución: ${visit.institution}
Fecha de visita: ${visit.visitDate}
Técnico: ${visit.technicianName || 'No especificado'}
Objetivo: ${visit.objective || 'No especificado'}
Observaciones: ${visit.observations || 'Ninguna'}
Estado: Completado
Creado: ${new Date(visit.createdAt).toLocaleDateString()}
      `;
    } else if (visit.type === 'scheduled') {
      details = `
VISITA PROGRAMADA

Institución: ${visit.institution}
Fecha programada: ${visit.visitDate}
Hora: ${visit.visitTime || 'No especificada'}
Técnico asignado: ${visit.assignedTechnician || 'No asignado'}
Objetivo: ${visit.objective || 'No especificado'}
Estado: ${visit.isResolved ? 'Realizada' : 'Pendiente'}
Creado: ${new Date(visit.createdAt).toLocaleDateString()}
      `;
    } else if (visit.type === 'incident') {
      details = `
INCIDENCIA

Institución: ${visit.institution}
Tipo: ${visit.incidentType || 'No especificado'}
Prioridad: ${visit.priority || 'Media'}
Estado: ${visit.isResolved ? 'Resuelta' : visit.status || 'Abierta'}
Técnico asignado: ${visit.assignedTechnician || 'No asignado'}
Descripción: ${visit.description || 'No especificada'}
Fecha del reporte: ${visit.visitDate}
Creado: ${new Date(visit.createdAt).toLocaleDateString()}
      `;
    }

    Alert.alert('Detalles', details.trim());
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'report': return '📋';
      case 'scheduled': return '📅';
      case 'incident': return '⚠️';
      default: return '📄';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'report': return 'Informe Técnico';
      case 'scheduled': return 'Visita Programada';
      case 'incident': return 'Incidencia';
      default: return 'Registro';
    }
  };

  const renderVisitItem = ({ item }: { item: Visit }) => {
    const typeIcon = getTypeIcon(item.type || 'report');
    const typeLabel = getTypeLabel(item.type || 'report');
    
    return (
      <View style={styles.visitCard}>
        {/* Header with type and date */}
        <View style={styles.cardHeader}>
          <Text style={styles.typeIcon}>{typeIcon}</Text>
          <Text style={styles.typeLabel}>{typeLabel} – {item.visitDate}</Text>
        </View>

        {/* Main content */}
        <View style={styles.cardContent}>
          <Text style={styles.objective}>
            {item.objective || item.description || `${item.incidentType || 'Actividad'} en ${item.institution}`}
          </Text>
          
          <View style={styles.technicianRow}>
            <Text style={styles.technicianIcon}>👤</Text>
            <Text style={styles.technicianText}>
              {item.type === 'incident' ? 'Reportada por' : 'Técnico'}: {item.technicianName || item.assignedTechnician || 'No asignado'}
            </Text>
          </View>

          {item.type === 'incident' && item.description && (
            <View style={styles.observationRow}>
              <Text style={styles.observationIcon}>📝</Text>
              <Text style={styles.observationText}>Observación: {item.description}</Text>
            </View>
          )}

          <View style={styles.statusRow}>
            <Text style={styles.statusIcon}>{item.isResolved ? '🟢' : '🟡'}</Text>
            <Text style={[styles.statusText, { color: item.isResolved ? '#059669' : '#D97706' }]}>
              Estado: {item.isResolved ? (item.type === 'report' ? 'Completado' : item.type === 'scheduled' ? 'Realizada' : 'Resuelta') : 'Pendiente'}
            </Text>
          </View>
        </View>

        {/* Action buttons */}
        <View style={styles.actionButtons}>
          {!item.isResolved && (item.type === 'scheduled' || item.type === 'incident') && (
            <TouchableOpacity
              style={styles.resolveButton}
              onPress={() => handleMarkAsResolved(item)}
            >
              <Text style={styles.resolveButtonText}>
                Marcar como {item.type === 'scheduled' ? 'Realizada' : 'Resuelta'}
              </Text>
            </TouchableOpacity>
          )}
          
          <View style={styles.smallButtonsRow}>
            <TouchableOpacity
              style={styles.smallButton}
              onPress={() => handleViewDetails(item)}
            >
              <Text style={styles.smallButtonText}>Ver detalles</Text>
            </TouchableOpacity>

            {item.type === 'report' && (
              <TouchableOpacity style={styles.smallButton}>
                <Text style={styles.smallButtonText}>Adjuntos</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Separator line */}
        <View style={styles.separator} />
      </View>
    );
  };

  return (
    <LinearGradient
      colors={['#f8fafc', '#e2e8f0']}
      style={styles.container}
    >
      <LinearGradient
        colors={['#FFC107', '#E0A800']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={() => router.push('/(tabs)')}
          >
            <Home color="#FFFFFF" size={24} />
          </TouchableOpacity>
          <Text style={styles.title}>Historial de Visitas</Text>
          <View style={styles.placeholder} />
        </View>
      </LinearGradient>

      <View style={styles.filtersContainer}>
        <View style={styles.searchContainer}>
          <Search color="#666" size={20} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Buscar..."
            placeholderTextColor="#9CA3AF"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>

      {filteredVisits.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📋</Text>
          <Text style={styles.emptyTitle}>No hay registros</Text>
          <Text style={styles.emptyText}>
            {visits.length === 0 
              ? 'Aún no has registrado ninguna actividad'
              : 'No se encontraron resultados para tu búsqueda'
            }
          </Text>
        </View>
      ) : (
        <FlatList
          data={filteredVisits}
          renderItem={renderVisitItem}
          keyExtractor={(item) => `${item.type}-${item.id}`}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  homeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 40,
  },
  filtersContainer: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E9ECEF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#E9ECEF',
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    paddingVertical: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#999',
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
  },
  listContainer: {
    padding: 20,
    paddingBottom: 100,
  },
  visitCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  typeIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  typeLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  cardContent: {
    marginBottom: 16,
  },
  objective: {
    fontSize: 15,
    color: '#333',
    marginBottom: 8,
    lineHeight: 20,
  },
  technicianRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  technicianIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  technicianText: {
    fontSize: 14,
    color: '#666',
  },
  observationRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 6,
  },
  observationIcon: {
    fontSize: 14,
    marginRight: 8,
    marginTop: 2,
  },
  observationText: {
    fontSize: 14,
    color: '#666',
    flex: 1,
    lineHeight: 18,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusIcon: {
    fontSize: 14,
    marginRight: 8,
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
  },
  actionButtons: {
    gap: 12,
  },
  resolveButton: {
    backgroundColor: '#F0FDF4',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#059669',
    alignItems: 'center',
  },
  resolveButtonText: {
    color: '#059669',
    fontSize: 14,
    fontWeight: '600',
  },
  smallButtonsRow: {
    flexDirection: 'row',
    gap: 8,
  },
  smallButton: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E9ECEF',
  },
  smallButtonText: {
    color: '#6C757D',
    fontSize: 12,
    fontWeight: '500',
  },
  separator: {
    height: 1,
    backgroundColor: '#E5E7EB',
    marginTop: 16,
    marginHorizontal: -20,
  },
});