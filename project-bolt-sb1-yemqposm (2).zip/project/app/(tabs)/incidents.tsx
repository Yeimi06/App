import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Image,
  Platform
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Chrome as Home, Building, TriangleAlert as AlertTriangle, MessageSquare, User, Calendar, Clock, Save, Camera, X } from 'lucide-react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';

export default function IncidentsScreen() {
  const [formData, setFormData] = useState({
    institution: '',
    incidentType: '',
    description: '',
    priority: 'Media',
    assignedTechnician: '',
    status: 'Abierta',
    reportDate: '',
    reportTime: ''
  });

  const [selectedFiles, setSelectedFiles] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showTypeDropdown, setShowTypeDropdown] = useState(false);
  const [showPriorityDropdown, setShowPriorityDropdown] = useState(false);
  const [showStatusDropdown, setShowStatusDropdown] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const incidentTypes = [
    'Red/Conectividad',
    'Hardware',
    'Software',
    'Equipos audiovisuales',
    'Sistemas operativos',
    'Aplicaciones educativas',
    'Otros'
  ];

  const priorityOptions = ['Alta', 'Media', 'Baja'];
  const statusOptions = ['Abierta', 'En proceso', 'Cerrada'];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.institution.trim()) {
      newErrors.institution = 'La institución es requerida';
    }
    if (!formData.incidentType.trim()) {
      newErrors.incidentType = 'El tipo de incidencia es requerido';
    }
    if (!formData.description.trim()) {
      newErrors.description = 'La descripción es requerida';
    }
    if (!formData.reportDate.trim()) {
      newErrors.reportDate = 'La fecha del reporte es requerida';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const requestPermissions = async () => {
    if (Platform.OS !== 'web') {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permisos requeridos', 'Se necesitan permisos para acceder a la galería');
        return false;
      }
      
      const cameraStatus = await ImagePicker.requestCameraPermissionsAsync();
      if (cameraStatus.status !== 'granted') {
        Alert.alert('Permisos requeridos', 'Se necesitan permisos para usar la cámara');
        return false;
      }
    }
    return true;
  };

  const handleAttachFiles = async () => {
    Alert.alert(
      'Adjuntar Archivo',
      'Selecciona el tipo de archivo',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Galería', onPress: () => pickImage() },
        { text: 'Cámara', onPress: () => takePhoto() },
        { text: 'Documento', onPress: () => pickDocument() }
      ]
    );
  };

  const pickImage = async () => {
    const hasPermissions = await requestPermissions();
    if (!hasPermissions) return;

    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const newFile = {
          id: Date.now().toString(),
          uri: result.assets[0].uri,
          type: 'image',
          name: `imagen_${Date.now()}.jpg`
        };
        setSelectedFiles(prev => [...prev, newFile]);
      }
    } catch (error) {
      Alert.alert('Error', 'No se pudo seleccionar la imagen');
    }
  };

  const takePhoto = async () => {
    const hasPermissions = await requestPermissions();
    if (!hasPermissions) return;

    try {
      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const newFile = {
          id: Date.now().toString(),
          uri: result.assets[0].uri,
          type: 'image',
          name: `foto_${Date.now()}.jpg`
        };
        setSelectedFiles(prev => [...prev, newFile]);
      }
    } catch (error) {
      Alert.alert('Error', 'No se pudo tomar la foto');
    }
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets[0]) {
        const newFile = {
          id: Date.now().toString(),
          uri: result.assets[0].uri,
          type: 'document',
          name: result.assets[0].name || `documento_${Date.now()}`
        };
        setSelectedFiles(prev => [...prev, newFile]);
      }
    } catch (error) {
      Alert.alert('Error', 'No se pudo seleccionar el documento');
    }
  };

  const removeFile = (id: string) => {
    setSelectedFiles(prev => prev.filter(file => file.id !== id));
  };

  const handleSaveIncident = async () => {
    if (!validateForm()) {
      Alert.alert('Error', 'Por favor completa los campos obligatorios');
      return;
    }

    setIsLoading(true);

    try {
      const existingIncidents = await AsyncStorage.getItem('incidents');
      const incidents = existingIncidents ? JSON.parse(existingIncidents) : [];

      const newIncident = {
        id: Date.now().toString(),
        ...formData,
        attachments: selectedFiles,
        isResolved: false, // Explicitly set as not resolved
        createdAt: new Date().toISOString()
      };

      incidents.push(newIncident);
      await AsyncStorage.setItem('incidents', JSON.stringify(incidents));

      // Create notification for unresolved incident
      await createIncidentNotification(newIncident);

      Alert.alert('Éxito', 'Incidencia registrada correctamente', [
        { text: 'OK', onPress: () => {
          setFormData({
            institution: '',
            incidentType: '',
            description: '',
            priority: 'Media',
            assignedTechnician: '',
            status: 'Abierta',
            reportDate: '',
            reportTime: ''
          });
          setSelectedFiles([]);
          setErrors({});
        }}
      ]);
    } catch (error) {
      Alert.alert('Error', 'No se pudo registrar la incidencia');
    } finally {
      setIsLoading(false);
    }
  };

  const createIncidentNotification = async (incidentData: any) => {
    try {
      const existingNotifications = await AsyncStorage.getItem('notifications');
      const notifications = existingNotifications ? JSON.parse(existingNotifications) : [];

      const newNotification = {
        id: `incident-${incidentData.id}`,
        type: 'incident',
        title: 'Nueva Incidencia Registrada',
        message: `${incidentData.incidentType} en ${incidentData.institution} - Prioridad: ${incidentData.priority}`,
        date: new Date().toISOString(),
        isRead: false,
        priority: incidentData.priority === 'Alta' ? 'high' : incidentData.priority === 'Media' ? 'medium' : 'low',
        data: incidentData
      };

      notifications.push(newNotification);
      await AsyncStorage.setItem('notifications', JSON.stringify(notifications));
    } catch (error) {
      console.error('Error creating notification:', error);
    }
  };

  return (
    <LinearGradient
      colors={['#f8fafc', '#e2e8f0']}
      style={styles.container}
    >
      <LinearGradient
        colors={['#DC3545', '#C82333']}
        style={styles.header}
      >
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.homeButton}
            onPress={() => router.push('/(tabs)')}
          >
            <Home color="#FFFFFF" size={24} />
          </TouchableOpacity>
          <Text style={styles.title}>Nueva Incidencia</Text>
          <View style={styles.placeholder} />
        </View>
      </LinearGradient>

      <ScrollView 
        style={styles.scrollContainer} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Información Básica</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Lugar / Escuela *</Text>
            <View style={[styles.inputContainer, errors.institution && styles.errorBorder]}>
              <Building color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Nombre de la institución"
                placeholderTextColor="#9CA3AF"
                value={formData.institution}
                onChangeText={(value) => handleInputChange('institution', value)}
              />
            </View>
            {errors.institution && <Text style={styles.errorText}>{errors.institution}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Fecha del Reporte *</Text>
            <View style={[styles.inputContainer, errors.reportDate && styles.errorBorder]}>
              <Calendar color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="DD/MM/YYYY"
                placeholderTextColor="#9CA3AF"
                value={formData.reportDate}
                onChangeText={(value) => handleInputChange('reportDate', value)}
              />
            </View>
            {errors.reportDate && <Text style={styles.errorText}>{errors.reportDate}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Hora del Reporte</Text>
            <View style={styles.inputContainer}>
              <Clock color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="HH:MM"
                placeholderTextColor="#9CA3AF"
                value={formData.reportTime}
                onChangeText={(value) => handleInputChange('reportTime', value)}
              />
            </View>
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Detalles de la Incidencia</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Tipo de Incidencia *</Text>
            <TouchableOpacity
              style={[styles.dropdownContainer, errors.incidentType && styles.errorBorder]}
              onPress={() => setShowTypeDropdown(!showTypeDropdown)}
            >
              <AlertTriangle color="#6B7280" size={20} style={styles.inputIcon} />
              <Text style={[styles.dropdownText, !formData.incidentType && styles.placeholder]}>
                {formData.incidentType || 'Selecciona el tipo de incidencia'}
              </Text>
            </TouchableOpacity>
            {errors.incidentType && <Text style={styles.errorText}>{errors.incidentType}</Text>}
            {showTypeDropdown && (
              <View style={styles.dropdownList}>
                {incidentTypes.map((type, index) => (
                  <TouchableOpacity
                    key={index}
                    style={styles.dropdownItem}
                    onPress={() => {
                      handleInputChange('incidentType', type);
                      setShowTypeDropdown(false);
                    }}
                  >
                    <Text style={styles.dropdownItemText}>{type}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Descripción del Problema *</Text>
            <View style={[styles.inputContainer, errors.description && styles.errorBorder]}>
              <MessageSquare color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={[styles.textInput, styles.textArea]}
                placeholder="Describe detalladamente el problema"
                placeholderTextColor="#9CA3AF"
                value={formData.description}
                onChangeText={(value) => handleInputChange('description', value)}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
              />
            </View>
            {errors.description && <Text style={styles.errorText}>{errors.description}</Text>}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Prioridad</Text>
            <TouchableOpacity
              style={styles.dropdownContainer}
              onPress={() => setShowPriorityDropdown(!showPriorityDropdown)}
            >
              <AlertTriangle color="#6B7280" size={20} style={styles.inputIcon} />
              <Text style={styles.dropdownText}>{formData.priority}</Text>
            </TouchableOpacity>
            {showPriorityDropdown && (
              <View style={styles.dropdownList}>
                {priorityOptions.map((priority, index) => (
                  <TouchableOpacity
                    key={index}
                    style={styles.dropdownItem}
                    onPress={() => {
                      handleInputChange('priority', priority);
                      setShowPriorityDropdown(false);
                    }}
                  >
                    <Text style={styles.dropdownItemText}>{priority}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Técnico Asignado</Text>
            <View style={styles.inputContainer}>
              <User color="#6B7280" size={20} style={styles.inputIcon} />
              <TextInput
                style={styles.textInput}
                placeholder="Nombre del técnico responsable"
                placeholderTextColor="#9CA3AF"
                value={formData.assignedTechnician}
                onChangeText={(value) => handleInputChange('assignedTechnician', value)}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Estado</Text>
            <TouchableOpacity
              style={styles.dropdownContainer}
              onPress={() => setShowStatusDropdown(!showStatusDropdown)}
            >
              <AlertTriangle color="#6B7280" size={20} style={styles.inputIcon} />
              <Text style={styles.dropdownText}>{formData.status}</Text>
            </TouchableOpacity>
            {showStatusDropdown && (
              <View style={styles.dropdownList}>
                {statusOptions.map((status, index) => (
                  <TouchableOpacity
                    key={index}
                    style={styles.dropdownItem}
                    onPress={() => {
                      handleInputChange('status', status);
                      setShowStatusDropdown(false);
                    }}
                  >
                    <Text style={styles.dropdownItemText}>{status}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Archivos Adjuntos</Text>
          
          <TouchableOpacity
            style={styles.attachButton}
            onPress={handleAttachFiles}
          >
            <Camera color="#4A90E2" size={20} />
            <Text style={styles.attachButtonText}>Adjuntar Fotos o Documentos</Text>
          </TouchableOpacity>

          {selectedFiles.length > 0 && (
            <View style={styles.filesContainer}>
              {selectedFiles.map((file) => (
                <View key={file.id} style={styles.fileItem}>
                  {file.type === 'image' ? (
                    <Image source={{ uri: file.uri }} style={styles.fileImage} />
                  ) : (
                    <View style={styles.documentIcon}>
                      <Text style={styles.documentText}>DOC</Text>
                    </View>
                  )}
                  <Text style={styles.fileName} numberOfLines={1}>{file.name}</Text>
                  <TouchableOpacity
                    style={styles.removeFileButton}
                    onPress={() => removeFile(file.id)}
                  >
                    <X color="#FFFFFF" size={16} />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={styles.actionCard}>
          <TouchableOpacity
            style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}
            onPress={handleSaveIncident}
            disabled={isLoading}
          >
            <Save color="#FFFFFF" size={20} style={styles.buttonIcon} />
            <Text style={styles.saveButtonText}>
              {isLoading ? 'Guardando...' : 'Guardar Incidencia'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  homeButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 40,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 100,
  },
  sectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minHeight: 52,
  },
  dropdownContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    minHeight: 52,
  },
  errorBorder: {
    borderColor: '#EF4444',
  },
  inputIcon: {
    marginRight: 12,
    marginTop: 2,
  },
  textInput: {
    flex: 1,
    fontSize: 16,
    color: '#374151',
    paddingVertical: 4,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  dropdownText: {
    flex: 1,
    fontSize: 16,
    color: '#374151',
  },
  placeholder: {
    color: '#9CA3AF',
  },
  dropdownList: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginTop: 4,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  dropdownItem: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  dropdownItemText: {
    fontSize: 16,
    color: '#374151',
  },
  errorText: {
    fontSize: 14,
    color: '#EF4444',
    marginTop: 4,
  },
  attachButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderWidth: 2,
    borderColor: '#4A90E2',
    borderStyle: 'dashed',
    marginBottom: 16,
  },
  attachButtonText: {
    color: '#4A90E2',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  filesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  fileItem: {
    position: 'relative',
    width: 100,
    alignItems: 'center',
  },
  fileImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    backgroundColor: '#F3F4F6',
  },
  documentIcon: {
    width: 80,
    height: 80,
    borderRadius: 8,
    backgroundColor: '#4A90E2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  fileName: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
    textAlign: 'center',
  },
  removeFileButton: {
    position: 'absolute',
    top: -8,
    right: 8,
    backgroundColor: '#EF4444',
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 4,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#DC3545',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
    shadowColor: '#DC3545',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  saveButtonDisabled: {
    backgroundColor: '#F5A5A5',
  },
  buttonIcon: {
    marginRight: 8,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});