import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { FileText, Calendar, History, TriangleAlert as AlertTriangle, LogOut } from 'lucide-react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HomeScreen() {
  const handleLogout = () => {
    Alert.alert(
      'Cerrar Sesión',
      '¿Estás seguro que deseas cerrar sesión?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Sí, cerrar sesión', 
          onPress: async () => {
            try {
              await AsyncStorage.removeItem('currentUser');
              router.replace('/');
            } catch (error) {
              console.error('Error logging out:', error);
              router.replace('/');
            }
          }
        }
      ]
    );
  };

  const menuItems = [
    {
      title: 'Informe Técnico',
      subtitle: 'Crear reportes técnicos',
      icon: FileText,
      colors: ['#6366F1', '#4F46E5', '#4338CA'],
      route: '/technical-report'
    },
    {
      title: 'Programar Visita',
      subtitle: 'Agendar visitas técnicas',
      icon: Calendar,
      colors: ['#059669', '#047857', '#065F46'],
      route: '/schedule-visit'
    },
    {
      title: 'Historial',
      subtitle: 'Ver registros anteriores',
      icon: History,
      colors: ['#7C3AED', '#6D28D9', '#5B21B6'],
      route: '/history'
    },
    {
      title: 'Incidencias',
      subtitle: 'Reportar problemas',
      icon: AlertTriangle,
      colors: ['#DC2626', '#B91C1C', '#991B1B'],
      route: '/incidents'
    }
  ];

  return (
    <LinearGradient
      colors={['#F1F5F9', '#E2E8F0', '#CBD5E1']}
      style={styles.container}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerTitle}>Inicio</Text>
        </View>
        <TouchableOpacity
          style={styles.logoutButton}
          onPress={handleLogout}
        >
          <LogOut color="#FFFFFF" size={20} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Welcome Section */}
        <View style={styles.welcomeSection}>
          <Text style={styles.welcomeTitle}>Bienvenido a VisiTec Coclé</Text>
          <Text style={styles.welcomeSubtitle}>Sistema de Registro Técnico</Text>
        </View>

        {/* Menu Grid */}
        <View style={styles.menuGrid}>
          {menuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.menuItemContainer}
              onPress={() => router.push(item.route as any)}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={item.colors}
                style={styles.menuItem}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <View style={styles.iconContainer}>
                  <item.icon color="#FFFFFF" size={28} />
                </View>
                <View style={styles.textContainer}>
                  <Text style={styles.menuItemTitle}>{item.title}</Text>
                  <Text style={styles.menuItemSubtitle}>{item.subtitle}</Text>
                </View>
                <View style={styles.arrowContainer}>
                  <Text style={styles.arrow}>→</Text>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  headerLeft: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  logoutButton: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#475569',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  scrollContainer: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 120,
  },
  welcomeSection: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 28,
    marginBottom: 32,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 6,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  welcomeTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1E293B',
    marginBottom: 8,
    textAlign: 'center',
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: '#64748B',
    textAlign: 'center',
    fontWeight: '500',
  },
  menuGrid: {
    gap: 16,
  },
  menuItemContainer: {
    marginBottom: 4,
  },
  menuItem: {
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 90,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 6,
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  textContainer: {
    flex: 1,
  },
  menuItemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  menuItemSubtitle: {
    fontSize: 13,
    color: 'rgba(255, 255, 255, 0.85)',
  },
  arrowContainer: {
    width: 32,
    alignItems: 'center',
  },
  arrow: {
    fontSize: 20,
    color: 'rgba(255, 255, 255, 0.8)',
    fontWeight: 'bold',
  },
});